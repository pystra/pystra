PySTRA 2.0.0a1: ex_active_subset

Install the matching development branch in your Python environment:

  python -m pip install "pystra[al] @ git+https://github.com/pystra/pystra.git@v2.0"
  python -m pip install jupyterlab

The branch changes during development; record the installed commit for
a reproducible study. Extract this entire bundle to one directory,
launch JupyterLab there, select that environment's Python kernel,
open ex_active_subset.ipynb, and run all cells from the top.

Optional dependencies: al. Included helpers: none.
Source: https://github.com/pystra/pystra/tree/v2.0/docs/source/notebooks
Method sources and benchmark assumptions are cited in the notebook.
