PySTRA 2.0.0: ex_literature_truss

Install the matching development branch in your Python environment:

  python -m pip install "pystra @ git+https://github.com/pystra/pystra.git@v2.0"
  python -m pip install jupyterlab

The branch changes during development; record the installed commit for
a reproducible study. Extract this entire bundle to one directory,
launch JupyterLab there, select that environment's Python kernel,
open ex_literature_truss.ipynb, and run all cells from the top.

Optional dependencies: core. Included helpers: literature_benchmarks.py.
Source: https://github.com/pystra/pystra/tree/v2.0/docs/source/notebooks
Method sources and benchmark assumptions are cited in the notebook.
